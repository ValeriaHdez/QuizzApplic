package hernandez.valeria.quizzapp2

import androidx.annotation.StringRes


data class Pregunta (@StringRes val TextoPregunta:Int, val Respuestas:Boolean)